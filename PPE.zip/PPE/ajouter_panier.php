<?php
// Inclure la page de connexion
include_once "config.php";

// Démarrer ou reprendre la session
session_start();

// Vérifier si un utilisateur est connecté
if (!isset($_SESSION['ouvert'])) {
    // Redirection vers la page de connexion si l'utilisateur n'est pas connecté
    header("Location: login.php");
    exit();
}

$ID_user = $_SESSION['ouvert'];

// Vérifier si un identifiant de produit est passé via l'URL et si la quantité est spécifiée
if (isset($_GET['id']) && is_numeric($_GET['id']) && isset($_GET['quantity']) && is_numeric($_GET['quantity'])) {
    $ID_produit = $_GET['id'];
    $quantite = $_GET['quantity'];

    // Créer la requête SQL pour vérifier si le produit est déjà dans le panier de l'utilisateur
    $query_check = "SELECT * FROM panier WHERE ID_user = ? AND ID_produit = ?";
    $stmt_check = mysqli_prepare($conn, $query_check);
    mysqli_stmt_bind_param($stmt_check, "ii", $ID_user, $ID_produit);
    mysqli_stmt_execute($stmt_check);
    $result_check = mysqli_stmt_get_result($stmt_check);

    if (mysqli_num_rows($result_check) > 0) {
        // Si le produit est déjà dans le panier, mettre à jour la quantité
        $row = mysqli_fetch_assoc($result_check);
        $quantite += $row['quantite'];
        $query_update = "UPDATE panier SET quantite = ? WHERE ID_user = ? AND ID_produit = ?";
        $stmt_update = mysqli_prepare($conn, $query_update);
        mysqli_stmt_bind_param($stmt_update, "iii", $quantite, $ID_user, $ID_produit);
        $resultat = mysqli_stmt_execute($stmt_update);
    } else {
        // Sinon, insérer le produit dans le panier avec la quantité spécifiée
        $query_insert = "INSERT INTO panier (ID_user, ID_produit, quantite) VALUES (?, ?, ?)";
        $stmt_insert = mysqli_prepare($conn, $query_insert);
        mysqli_stmt_bind_param($stmt_insert, "iii", $ID_user, $ID_produit, $quantite);
        $resultat = mysqli_stmt_execute($stmt_insert);
    }

    if ($resultat) {
        // Redirection vers la page du panier
        header("Location: panier.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Une erreur s'est produite lors de l'ajout du produit au panier.";
    }
} else {
    $_SESSION['error_message'] = "Identifiant de produit ou quantité non valide.";
}

// Redirection vers la page précédente en cas d'erreur
header("Location: {$_SERVER['HTTP_REFERER']}");
exit();

?>