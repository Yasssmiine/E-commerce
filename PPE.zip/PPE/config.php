<?php

$conn = mysqli_connect("localhost", "root", "", "ya");
$conn -> set_charset("utf8");

?>
