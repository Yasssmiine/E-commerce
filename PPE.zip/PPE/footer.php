<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="yass.css">

</head>

<body>
    
    <div class="contact-footer">
        <h3>Follow Us</h3>
        <div class="social-links">
            <a href="https://www.facebook.com/"><i class='bx bxl-facebook-circle'></i></a>
            <a href="https://twitter.com/?lang=fr"><i class='bx bxl-twitter'></i></a>
            <a href="https://www.instagram.com/"><i class='bx bxl-instagram'></i></a>
            <a href="https://www.linkedin.com/"><i class='bx bxl-linkedin-square'></i></a>
            <a href="https://www.youtube.com/"><i class='bx bxl-youtube'></i></a>
        </div>
    </div>

   
</body>

</html>