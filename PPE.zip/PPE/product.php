<?php
include_once('header.php');

// Inclusion du fichier de configuration de la base de données
require_once('config.php');

// Démarrer ou reprendre la session
session_start();

// Vérifier si un utilisateur est connecté
if (!isset($_SESSION['ouvert'])) {
    echo "Vous devez être connecté pour accéder à cette page.";
    exit();
}

$id = $_GET['id'] ?? null;

// Vérifier si un identifiant de produit est passé via l'URL
if (!$id) {
    echo "Identifiant de produit non spécifié.";
    exit();
}

// Récupérer les détails du produit depuis la base de données
$query = "SELECT * FROM produit WHERE ID_produit = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (!$result || mysqli_num_rows($result) === 0) {
    echo "Produit non trouvé.";
    exit();
}

$produit = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $produit['Nom'] ?></title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header>
        <h1><?= $produit['Nom'] ?></h1>
    </header>
    <section>
        <img src="images/<?= $produit['Image'] ?>" alt="<?= $produit['Nom'] ?>">
        <p>Description : <?= $produit['Description'] ?></p>
        <p>Prix : <?= $produit['Prix'] ?> €</p>
        <label for="quantity">Quantité :</label>
        <input type="number" id="quantity" name="quantity" value="1">
        <button onclick="addToCart(<?= $id ?>)">Ajouter au panier</button>
    </section>

    <script>
        function addToCart(productId) {
            var quantity = document.getElementById("quantity").value;
            window.location.href = "ajouter_panier.php?id=" + productId + "&quantity=" + quantity;
        }
    </script>
</body>

</html>