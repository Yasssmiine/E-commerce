<?php
echo "Bienvenue !";
header("refresh:2;url=Form.php");
?>
