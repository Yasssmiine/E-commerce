-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  sam. 25 mai 2024 à 23:02
-- Version du serveur :  10.4.10-MariaDB
-- Version de PHP :  7.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `ya`
--

-- --------------------------------------------------------

--
-- Structure de la table `commandeenattente`
--

DROP TABLE IF EXISTS `commandeenattente`;
CREATE TABLE IF NOT EXISTS `commandeenattente` (
  `ID_commande` int(11) NOT NULL AUTO_INCREMENT,
  `ID_user` int(11) DEFAULT NULL,
  `ID_produit` int(11) DEFAULT NULL,
  `quantite` int(11) DEFAULT NULL,
  `date_creation` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID_commande`),
  KEY `ID_user` (`ID_user`),
  KEY `ID_produit` (`ID_produit`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `panier`
--

DROP TABLE IF EXISTS `panier`;
CREATE TABLE IF NOT EXISTS `panier` (
  `ID_panier` int(11) NOT NULL AUTO_INCREMENT,
  `ID_user` int(11) DEFAULT NULL,
  `ID_produit` int(11) DEFAULT NULL,
  `quantite` int(11) DEFAULT NULL,
  `date_ajout` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID_panier`),
  KEY `ID_user` (`ID_user`),
  KEY `ID_produit` (`ID_produit`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

DROP TABLE IF EXISTS `produit`;
CREATE TABLE IF NOT EXISTS `produit` (
  `ID_produit` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(200) NOT NULL,
  `Ref` varchar(50) NOT NULL,
  `Prix` decimal(10,0) NOT NULL,
  `Couleur` varchar(200) NOT NULL,
  `couleur_test` int(11) NOT NULL,
  `Genre` varchar(100) NOT NULL,
  `Description` varchar(999) NOT NULL,
  `Image` varchar(250) DEFAULT NULL,
  `Image2` varchar(250) DEFAULT NULL,
  `Image3` varchar(250) DEFAULT NULL,
  `Image4` varchar(200) NOT NULL,
  PRIMARY KEY (`ID_produit`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`ID_produit`, `Nom`, `Ref`, `Prix`, `Couleur`, `couleur_test`, `Genre`, `Description`, `Image`, `Image2`, `Image3`, `Image4`) VALUES
(1, 'Nike Dunk Low', '213 01', '109', 'Couleur affichée : Brume indigo/Voile/Corail craie', 0, 'Chaussure pour femme', 'Conçue pour les parquets mais aujourd\'hui star urbaine, l\'icône du basketball des années 80 fait son grand retour avec des renforts brillants et des couleurs classiques évoquant les équipes universitaires. Avec son design emblématique du basketball, la Nike Dunk Low invite l\'esthétique des années 80 dans l\'espace urbain, tandis que son col bas et rembourré vous permet de la porter partout, avec un maximum de confort.', '213_01_1.png', '213_01_2.png', '213_01_3.png', '213_01_4.png'),
(2, 'Nike Air Force 1 \'07', '213 02', '129', 'Couleur affichée : Blanc/Vert action', 0, 'Chaussure pour femme', 'Le charme continue d\'opérer avec la Nike Air Force 1 \'07. Cette silhouette emblématique du basketball apporte un nouveau souffle à ses éléments les plus remarquables : le cuir impeccable, les couleurs vives et juste ce qu\'il faut d\'éclat pour vous faire briller.', '213_02_1.png', '213_02_2.png', '213_02_3.png', '213_02_4.png'),
(3, 'Nike Air Force 1 \'07', '213 03', '119', 'Couleur affichée : Blanc/Blanc/Blanc/Blanc', 0, 'Chaussure pour femme', 'Le charme continue d\'opérer avec la Nike Air Force 1 \'07. Cette silhouette emblématique du basketball apporte un nouveau souffle à ses éléments les plus remarquables : le cuir impeccable, les couleurs vives et juste ce qu\'il faut d\'éclat pour vous faire briller.', '213_03_1.png', '213_03_2.png', '213_03_3.png', '213_03_4.png'),
(4, 'Nike TC 7900', '213 04', '200', 'Couleur affichée : Voile/Noir/Voile', 0, 'Chaussure pour femme', 'Conçue pour être à l\'épreuve du quotidien, la Nike TC 7900 vous accompagnera dans toutes vos aventures. Le col rembourré et l\'amorti en mousse souple apportent un confort durable.', '213_04_1.png', '213_04_2.png', '213_04_3.png', '213_04_4.png'),
(5, 'Nike P-6000', '213 05', '109', 'Couleur affichée : Blanc/Platine métallique/Noir/Bleu photo', 0, 'Chaussure pour femme', 'Mélangeant des éléments d\'anciennes Pegasus, la Nike P-6000 fait entrer le running du début des années 2000 dans la modernité. Mesh, renforts respirants et lignes sportives pour un mix parfait entre style et confort. L\'amorti en mousse ajoute de la hauteur pour un look running inspiré des pistes tout en confort.', '213_05_1.png', '213_05_2.png', '213_05_3.png', '213_05_4.png'),
(6, 'Nike Air Monarch IV', '213 06', '75', 'Couleur affichée : Noir/Noir', 0, 'Chaussure pour femme', 'La Nike Air Monarch IV vous permet de faire du sport grâce à son cuir résistant sur le dessus pour assurer le maintien de votre pied. Sa mousse légère s\'associe à un amorti Nike Air pour plus de confort à chaque foulée.', '213_06_1.png', '213_06_2.png', '213_06_3.png', '213_06_4.png'),
(7, 'Nike Dunk Low', '213 07', '109', 'Couleur affichée : Blanc/Blanc/Noir', 0, 'Chaussure pour femme', 'Conçue pour les parquets mais aujourd\'hui star urbaine, l\'icône du basketball des années 80 fait son grand retour avec des renforts brillants et des couleurs classiques évoquant les équipes universitaires. Avec son design emblématique du basketball, la Nike Dunk Low invite l\'esthétique des années 80 dans l\'espace urbain, tandis que son col bas et rembourré vous permet de la porter partout, avec un maximum de confort.', '213_07_1.png', '213_07_2.png', '213_07_3.png', '213_07_4.png'),
(8, 'Nike Blazer Mid \'77', '213 08', '150', 'Couleur affichée : Blanc/Voile/Volt/Vert de chrome', 0, 'Chaussure pour femme', 'Imaginée dans les années 70. Adoptée dans les années 80. Sanctifiée dans les années 90. Prête pour la suite. La Nike Blazer Mid ’77 présente un design intemporel et facile à porter. L\'empeigne en cuir s\'assouplit à la perfection et s\'associe aux détails en daim et au logo rétro pour un look et un confort exceptionnels. La mousse visible sur la languette et la finition spéciale sur la semelle intermédiaire donnent l\'impression que tu conserves cette paire depuis des décennies.\r\n\r\n', '213_08_1.png', '213_08_2.png', '213_08_3.png', '213_08_4.png'),
(9, 'Nike Air Monarch IV', '213 09', '75', 'Couleur affichée : Blanc/Argent métallique', 0, 'Chaussure pour femme', 'Largeur de la monture : 125mm  Hauteur du verre : 51mm Largeur du verre : 54mm Longueur de la branche : 145mm', '213_09_1.png', '213_09_2.png', '213_09_3.png', '213_09_4.png'),
(10, 'Nike Vaporfly 3', '213 10', '235', 'Couleur affichée : Blanc/Gris particule/Argent métallique/Gris fumée foncé', 0, 'Chaussure pour femme', 'Attrapez-les si vous le pouvez. En vous donnant la vitesse du jour de la course pour conquérir n\'importe quelle distance, la Nike Vaporfly 3 est faite pour les chasseurs, les coureurs et les meneurs élevés qui ne peuvent pas refuser le frisson de la poursuite. Nous avons retravaillé le leader du super pack de chaussures et réglé le moteur en dessous pour vous aider à poursuivre vos records personnels d\'un 10 km au marathon. Des coureurs d\'élite aux débutants en course, ce bourreau de travail polyvalent de course sur route est destiné à ceux qui voient la vitesse comme une passerelle vers plus de kilomètres et plus de sommets apparemment inatteignables.', '213_10_1.png', '213_10_2.png', '213_10_3.png', '213_10_4.png'),
(11, 'Nike Tech Hera', '213 11', '99', 'Couleur affichée : Fantôme/Phantom/Brun Orewood clair', 0, 'Chaussure pour femme', 'La Tech Hera est là pour répondre à tous vos souhaits en matière de grosses baskets. La semelle intercalaire surélevée ondulée et les accents en daim rehaussent votre look tout en vous gardant à l\'aise. Sa conception durable résiste parfaitement à l\'usure quotidienne, ce qui est parfait, car vous voudrez certainement les porter tous les jours.', '213_11_1.png', '213_11_2.png', '213_11_3.png', '213_11_4.png'),
(12, 'Nike Air Max Bliss', '213 12', '125', 'Couleur affichée : Blanc/Blanc/Blanc sommet', 0, 'Chaussure pour femme\r\n', 'Pour les jours où vous voulez être à la fois confortable et élégant, tout ce que vous avez à faire est de vous en procurer une paire. Cette chaussure est tout au sujet de la fluidité, avec juste les bonnes touches de couleur pour ajouter de l\'intérêt à n\'importe quel look. L\'assise plantaire extra-confortable bénéficie de la technologie Air Max et l\'esthétique inspirée de la nature vous garde juste assez ancré.', '213_12_1.png', '213_12_2.png', '213_12_3.png', '213_12_4.png'),
(13, 'Nike Dunk High 1985', '213 13', '139', 'Couleur affichée : Orange arctique/Blanc sommet/Orange flamboyant/Orange arctique', 0, 'Chaussure pour femme', 'Célébrez le passé avec une version actualisée de la Dunk High, remodelée pour refléter le modèle original de 1985. Reprenant la silhouette, le look et les sensations qui ont fait sa renommée, elle affiche un style rétro tout en conservant le confort familier que vous aimez.', '213_13_1.png', '213_13_2.png', '213_13_3.png', '213_13_4.png'),
(14, 'Nike Dunk High', '213 14', '119', 'Couleur affichée : Marron clair/Blanc sommet/Lait de noix de coco/Bordeaux foudre', 0, 'Chaussure pour femme', 'Adoptez un style de haut vol avec cette légende du basketball. La Nike Dunk fait son grand retour avec un design montant classique apportant l\'esprit du terrain au quotidien. Le rembourrage autour du col vous enveloppe dans un confort moelleux, et les tons neutres épurés font dunker votre style en toute simplicité.', '213_14_1.png', '213_14_2.png', '213_14_3.png', '213_14_4.png'),
(15, 'Air Jordan 11 CMFT Low', '213 15', '125', 'Couleur affichée : Blanc/Blanc/Bleu glacier', 0, 'Chaussure pour femme', 'Inspirée des sneakers Jordan classiques, cette chaussure basse vous offre encore plus de confort avec une pointe en cuir ultra-souple. La mousse souple sous le pied est dotée de renforts en caoutchouc pour une adhérence ciblée, tandis que les passants facilitent le laçage.', '213_15_1.png', '213_15_2.png', '213_15_3.png', '213_15_4.png'),
(18, 'Nike Dunk Low', '213 16', '119', 'Couleur affichée : Gris football/Blanc/Cramoisi brillant/Bleu marine nuit', 0, 'Chaussure pour homme', 'Conçue pour les parquets mais adoptée par le streetwear, l\'icône du basket des années 80 fait son grand retour avec des détails classiques et un style rétro inspiré du terrain. Les renforts en daim souple apportent une touche vintage à cette Nike Dunk, et le col bas rembourré te permet de la porter partout, dans le plus grand confort. Les touches de couleur subtiles rendent hommage au 40e anniversaire de la Pegasus. Comme ça, tu peux célébrer l\'héritage des sneakers à chacun de tes pas.', '213_16_1.png', '213_16_2.png', '213_16_3.png', '213_16_4.png'),
(19, 'Nike Air Force 1 \'07', '213 17', '119', 'Couleur affichée : Blanc/Blanc', 0, 'Chaussure pour homme', 'Le charme continue d\'opérer avec la Nike Air Force 1 ’07. Cette chaussure de basketball OG revisite ses éléments les plus célèbres : les renforts cousus résistants, les finitions sobres et juste ce qu\'il faut d\'éclat pour vous faire briller.', '213_17_1.png', '213_17_2.png', '213_17_3.png', '213_17_4.png'),
(20, 'Nike Air Force 1 \'07', '213 18', '119', 'Couleur affichée : Noir/Noir', 0, 'Chaussure pour homme', 'Le charme continue d\'opérer avec la Nike Air Force 1 ’07. Cette chaussure de basketball OG revisite ses éléments les plus célèbres : les renforts cousus résistants, les finitions sobres et juste ce qu\'il faut d\'éclat pour vous faire briller.', '213_18_1.png', '213_18_2.png', '213_18_3.png', '213_18_4.png'),
(21, 'Nike Air Max Plus Utility', '213 19', '199', 'Couleur affichée : Blanc/Orange sécurité/Platine pur', 0, 'Chaussure pour homme', 'Inspirée par la plage mais conçue pour la ville, la Nike Air Max Plus Utility revient dans une version plus robuste, parfaite pour tes aventures urbaines. L\'empeigne en maille respirante intègre un nouveau renfort latéral en daim robuste. Un jeu supplémentaire de lacets avec fermeture à stoppeur apporte la touche finale, tout en assurant une tenue sûre et un bon maintien. Les unités Max Air visibles à l\'avant-pied et au talon créent une expérience Tuned Air qui allie confort et style rebelle.', '213_19_1.png', '213_19_2.png', '213_19_3.png', '213_19_4.png'),
(23, 'Nike Air Max Plus Utility', '213 20', '199', 'Couleur affichée : Noir/Blanc/Argent métallique', 0, 'Chaussure pour homme', 'Inspirée par la plage mais conçue pour la ville, la Nike Air Max Plus Utility revient dans une version plus robuste, parfaite pour tes aventures urbaines. L\'empeigne en maille respirante intègre un nouveau renfort latéral en daim robuste. Un jeu supplémentaire de lacets avec fermeture à stoppeur apporte la touche finale, tout en assurant une tenue sûre et un bon maintien. Les unités Max Air visibles à l\'avant-pied et au talon créent une expérience Tuned Air qui allie confort et style rebelle.', '213_20_1.png', '213_20_2.png', '213_20_3.png', '213_20_4.png'),
(24, 'Nike Air Max Terrascape Plus', '213 20', '199', 'Couleur affichée : Blanc/Blanc/Blanc/Platine pur', 0, 'Chaussure pour homme', 'Style rebelle des années 90 revisité. Les détails robustes, notamment des pointes renforcées et une cage en plastique résistante, renforcent votre esprit aventurier avec un style inspiré des grands espaces. Et pour une plus grande stabilité, la semelle intermédiaire innovante en mousse Crater rehausse encore votre expérience Tuned Air.', '213_21_1.png', '213_21_2.png', '213_21_3.png', '213_21_4.png'),
(25, 'Nike Air Max Terrascape Plus', '213 22', '199', 'Couleur affichée : Noir/Aqua bruit/Anthracite/Corail marin', 0, 'Chaussure pour homme', 'Style rebelle des années 90 revisité. Les détails robustes, notamment des pointes renforcées et une cage en plastique résistante, renforcent votre esprit aventurier avec un style inspiré des grands espaces. Et pour une plus grande stabilité, la semelle intermédiaire innovante en mousse Crater rehausse encore votre expérience Tuned Air.', '213_22_1.png', '213_22_2.png', '213_22_3.png', '213_22_4.png'),
(26, 'Nike Air Max Terrascape Plus', '213 23', '199', 'Couleur affichée : Noir/Anthracite/Noir/Anthracite', 0, 'Chaussure pour homme', 'Style rebelle des années 90 revisité. Les détails robustes, notamment des pointes renforcées et une cage en plastique résistante, renforcent votre esprit aventurier avec un style inspiré des grands espaces. Et pour une plus grande stabilité, la semelle intermédiaire innovante en mousse Crater rehausse encore votre expérience Tuned Air.', '213_23_1.png', '213_23_2.png', '213_23_3.png', '213_23_4.png'),
(27, 'Nike Air VaporMax 2021 FK', '213 24', '219', 'Couleur affichée : Blanc/Noir/Argent métallique/Blanc', 0, 'Chaussure pour homme', 'Fabriquée avec au moins 40 % de son poids en matières recyclées, la Nike Air VaporMax 2021 FK intègre du tissu Flyknit recyclé et ultra-extensible (ainsi qu\'un col souple qui épouse la forme de votre cheville) pour vous offrir un confort respirant et un style facile à porter.Le Swoosh cousu et le clip en TPU recyclé au talon apportent une touche d\'éclat à chacun de vos pas, tandis que l\'amorti VaporMax vous offre un amorti incroyablement souple.', '213_24_1.png', '213_24_2.png', '213_24_3.png', '213_24_4.png'),
(28, 'Nike Air Max Plus', '213 25', '189', 'Couleur affichée : Blanc/Platine pur/Blanc', 0, 'Chaussure pour homme', 'Revendiquez votre côté rebelle avec la Nike Air Max Plus, un modèle Air novateur qui offre une stabilité optimale et un amorti exceptionnel. Avec son mesh respirant, elle présente les lignes ondulées ainsi que les détails en TPU poli sur la pointe et les côtés du modèle d\'origine pour mettre en valeur votre style audacieux.', '213_25_1.png', '213_25_2.png', '213_25_3.png', '213_25_4.png'),
(29, 'Nike Dunk Low', '213 26', '59', 'Couleur affichée : Platine pur/Gris loup/Blanc', 0, 'Chaussure pour bébé et petit enfant', 'Affichez votre nostalgie des années 80 avec la Nike Dunk Low. De la conception résistante au toucher et à la forme de la chaussure, nous rendons hommage à cette icône incontournable des parquets, qui sera la prochaine paire à rejoindre la collection de sneakers de votre enfant.', '213_26_1.png', '213_26_2.png', '213_26_3.png', '213_26_4.png'),
(30, 'Nike Revolution 6', '213 27', '39', 'Couleur affichée : Blanc sommet/Beige clair/Bleu diffus', 0, 'Chaussure pour bébé et petit enfant', 'Le confort est notre priorité, en particulier pour nos athlètes en pleine croissance. Fabriquée avec 20 % de matières recyclées en poids, cette sneaker légère et respirante accompagne votre enfant tout au long de la journée.', '213_27_1.png', '213_27_2.png', '213_27_3.png', '213_27_4.png'),
(31, 'Jordan Flare', '213 28', '45', 'Couleur affichée : Noir/Blanc', 0, 'Chaussure pour bébé et petit enfant', 'Idéale pour les enfants actifs, la Jordan Flare est légère, respirante et confortable. Elle est facile à enfiler, munie d\'une bande au talon pour l\'empêcher de glisser, et l\'avant est renforcé pour protéger les ongles.', '213_28_1.png', '213_28_2.png', '213_28_3.png', '213_28_4.png'),
(32, 'Nike Air Max Plus', '213 29', '105', 'Couleur affichée : Blanc/Orange laser/Argent réfléchissant/Rouge université', 0, 'Chaussure pour bébé et petit enfant', 'Qui a dit que les petits pieds n\'ont pas besoin d\'un grand amorti ? Pas nous. Offre à ton enfant un avant-goût de Max Air avec cette sneaker confortable. Elle affiche un design inspiré de la Air Max Plus d\'origine, revisité avec des couleurs qui vont enflammer ses pas.', '213_29_1.png', '213_29_2.png', '213_29_3.png', '213_29_4.png'),
(33, 'Nike Dunk Low', '213 30', '59', 'Couleur affichée : Gris football/Rose perle/Bleu sarcelle minéral\r\n', 0, 'Chaussure pour bébé et petit enfant', 'Avec la Nike Dunk Low, votre enfant brillera comme une All-Star. Cette chaussure a un passé incroyable. Elle a d\'abord été adoptée par les joueurs de basketball dans les années 80. Avant de devenir une icône du skateboard. Pour être aujourd\'hui considérée comme une légende du streetwear. Le cuir résistant permet à ces sneakers de durer et la semelle en caoutchouc offre une meilleure adhérence qui permet aux enfants de jouer n\'importe où, des trottoirs aux terrains de jeu, en passant par le parc.', '213_30_1.png', '213_30_2.png', '213_30_3.png', '213_30_3.png'),
(37, 'Nike Air Max INTRLK Lite', '213 31', '45', 'Couleur affichée : Blanc/Poudre de photons/Gris loup/Noir', 0, 'Chaussure pour bébé et petit enfant', 'Une nouvelle expérience Air Max pour votre enfant ? Comment ne pas craquer ? La Nike Air Max INTRLK Lite revisite notre amorti Air préféré pour offrir une sensation de douceur et de confort qui permettra à votre enfant de jouer toute la journée. Parfaite pour annoncer une nouvelle évolution de l\'Air, cette chaussure légère et ultra-facile à enfiler comme à retirer est résistante et polyvalente, pour répondre à tous les besoins de votre enfant.', '213_31_1.png', '213_31_2.png', '213_31_3.png', '213_31_4.png'),
(38, 'AZE', 'MBZPEEO', '123', 'BLEU', 12, 'FEMME', 'MBAPPE', NULL, NULL, NULL, '213_25_4.png');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `ID_user` int(11) NOT NULL AUTO_INCREMENT,
  `Email` varchar(50) NOT NULL,
  `Pass` text NOT NULL,
  `Nom` varchar(50) NOT NULL,
  `Prenom` varchar(50) NOT NULL,
  PRIMARY KEY (`ID_user`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`ID_user`, `Email`, `Pass`, `Nom`, `Prenom`) VALUES
(20, 'Nom@ya.fr', '$2y$12$UHXGDR5GoXkUDP7iVs8.2.8iGLe1SolJhYZZr/Y4ONG/4Eoq1K9a2', 'Nom', 'Nom'),
(21, 'Papa@ya.fr', '$2y$12$AZCpfkiZMRGct6IZVM4og.oVkamQzDln/ZaqHvGjIrd8CG4Jt2A0O', 'yas', 'papa'),
(16, 'mamine1@yahoo.fr', 'Mamine1!', 'mamine', 'mohammed'),
(24, 'marwan25@yahoo.com', '$2y$12$q0jAMlsUrFPtC72cUavyJ.bWxC3/2DPDhhYqBVSq8nWuzdttpM6bK', 'marwan', 'marwan'),
(17, 'yass@yahoo.fr', '$2y$12$WGAkVEdrD9zhSqXn84rMCu/X9Y/3Slwgl09YzSBmSpFBskm9DCv6m', 'fjen', 'ejie'),
(18, 'lae@yahoo.fr', '$2y$12$JJ5eotO9ovXiSUMLRRd4WuA97IxMfMiLgQWogGTMPRgNsQltVe2Je', 'lae', 'laetitia'),
(19, 'marwan@yahoo.fr', '$2y$12$bjIiiQ9ScTFvKTzzu7XGp.ttl1mMBHJfZJhN8cpksgYQfYPPoYLzG', 'marwan', 'marwa'),
(22, 'a@ya.fr', '$2y$12$4obAV5OaNJngso0XVLbaQOappbHJfx6zrVV/j6ZlYiZpS9He3c8hS', 'a', 'b'),
(23, 'ya@ya.fr', '$2y$12$P0wsTHye0YNTSn1ofRUbKuPcRyiV7df5VucHdF23G023pDKacFtUK', 'm', 'c'),
(25, 'akaki@sandra.fr', 'akaki', 'akaki', 'akaki');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
